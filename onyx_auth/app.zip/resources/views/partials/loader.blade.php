<div class="loader-center hidden">
  <div class="spinner-border text-primary" role="status">
    <span class="sr-only"></span>
  </div>
</div>