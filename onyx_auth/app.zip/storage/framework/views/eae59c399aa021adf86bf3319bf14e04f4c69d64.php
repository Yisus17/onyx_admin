

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">

			<!-- Breadcrumbs -->
			<?php echo e(Breadcrumbs::render('clients.show', $client)); ?>


			<!-- Session messages -->
			<?php echo $__env->make('partials.session_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="card">
				<div class="card-header d-flex justify-content-between align-items-center">
					<span>Detalles del contacto</span>
				</div>
				<div class="card-body">
					<table class="table table-bordered">
						<tbody>
							<tr>
								<th>Razón social</th>
								<td><?php echo e($client->business_name); ?></td>
							</tr>
							<tr>
								<th>Dirección</th>
								<td><?php echo e($client->address); ?></td>
							</tr>
							<tr>
								<th>Código postal</th>
								<td><?php echo e($client->postal_code); ?></td>
							</tr>
							<tr>
								<th>Comunidad autónoma</th>
								<td><?php echo e(isset($client->clientType) ? $client->clientType->name : ''); ?></td>
							</tr>
							<tr>
								<th>Teléfono</th>
								<td><?php echo e($client->phone); ?></td>
							</tr>
							<tr>
								<th>Teléfono secundario</th>
								<td><?php echo e($client->secondary_phone); ?></td>
							</tr>
							<tr>
								<th>Nombre</th>
								<td><?php echo e($client->name); ?></td>
							</tr>
							<tr>
								<th>Apellido</th>
								<td><?php echo e($client->lastname); ?></td>
							</tr>
							<tr>
								<th>Email</th>
								<td><?php echo e($client->email); ?></td>
							</tr>
							<tr>
								<th>Tipo</th>
								<td><?php echo e(isset($client->community) ? $client->community->name : ''); ?></td>
							</tr>
						</tbody>
					</table>
					<a href="<?php echo e(route('clients.edit', $client)); ?>" class="btn btn-primary">Editar</a>
					<a href="/clients" class="btn btn-secondary">Volver</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/clients/show.blade.php ENDPATH**/ ?>