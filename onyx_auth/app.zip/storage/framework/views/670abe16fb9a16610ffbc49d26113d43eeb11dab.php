<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col"><span class="guide-field">*</span>#</th>
        <th scope="col"><span class="guide-field">*</span>Contacto</th>
        <th scope="col">Fecha de creación</th>
        <th scope="col">Descripción</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->client->business_name); ?></td>
        <td><?php echo e($item->created_at ? $item->created_at->format('d/m/Y H:m') : ''); ?></td>
        <td><?php echo e(truncateText($item->description, 20)); ?></td>
        <td>
          <form action="<?php echo e(route('budgets.destroy',$item->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro que deseas eliminar a este presupuesto?');">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <a href="<?php echo e(route('budgets.show', $item->id)); ?>" class="btn btn-primary btn-sm" title="Mostrar presupuesto"><i class="fas fa-eye"></i></a>
            <a href="<?php echo e(route('budgets.edit', $item)); ?>" class="btn btn-success btn-sm" title="Editar presupuesto"><i class="fas fa-edit"></i></a>
            <a href="<?php echo e(route('budgets.excelExport', $item->id)); ?>" class="btn btn-success btn-sm" title="Descargar excel"><i class="fas fa-file-excel"></i></a>
            <a href="<?php echo e(route('budgets.duplicate', $item->id)); ?>" class="btn btn-primary btn-sm" title="Duplicar presupuesto" onclick="return confirm('¿Estás seguro que deseas duplicar a este presupuesto?');"><i class="fas fa-copy"></i></a>
            <button type="submit" class="btn btn-danger btn-sm" title="Eliminar presupuesto"><i class="fa fa-minus-circle"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php echo e($budgets->links()); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/partials/results.blade.php ENDPATH**/ ?>