

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">
			<!-- Breadcrumbs -->
			<?php echo e(Breadcrumbs::render('products.show', $product)); ?>


			<!-- Session messages -->
			<?php echo $__env->make('partials.session_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="card">
				<div class="card-header d-flex justify-content-between align-items-center">
					<span>Detalles del producto</span>
				</div>
				<div class="card-body">
					<table class="table table-bordered">
						<tbody>
							<tr>
								<th>Código</th>
								<td><?php echo e($product->code); ?></td>
							</tr>
							<tr>
								<th>Marca</th>
								<td><?php echo e($product->brand); ?></td>
							</tr>
							<tr>
								<th>Modelo</th>
								<td><?php echo e($product->model); ?></td>
							</tr>
							<tr>
								<th>Descripción</th>
								<td><?php echo e($product->description); ?></td>
							</tr>
							<tr>
								<th>Rubro</th>
								<td><?php echo e($product->category->name); ?></td>
							</tr>
							<tr>
								<th>Tipo</th>
								<td><?php echo e($product->type); ?></td>
							</tr>
							<tr>
								<th>Serial</th>
								<td><?php echo e($product->serial); ?></td>
							</tr>
							<tr>
								<th>Precio de compra</th>
								<td><?php echo e($product->purchase_price ? $product->purchase_price.'€' : ''); ?></td>
							</tr>
							<tr>
								<th>Estado</th>
								<td><?php echo e($product->status); ?></td>
							</tr>
							<tr>
								<th>Comprado por</th>
								<td><?php echo e($product->bought_by); ?></td>
							</tr>
							<tr>
								<th>Fecha de compra</th>
								<td><?php echo e($product->purchase_date ? $product->purchase_date->format('d/m/Y') : ''); ?></td>
							</tr>
							<tr>
								<th>Años de antigüedad</th>
								<td><?php echo e($product->years_old); ?></td>
							</tr>
							<tr>
								<th>Imagen</th>
								<td>
									<?php if(isset($product) && $product->image_name): ?>
										<input type="image" src="<?php echo e(url('uploads/products/'.$product->image_name)); ?>" width="50" height="50">
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<th>Contable</th>
								<td><?php echo e($product->countable ? 'Si' : 'No'); ?></td>
							</tr>
						</tbody>
					</table>
					<a href="<?php echo e(route('products.edit', $product)); ?>" class="btn btn-primary">Editar</a>
					<a href="/products" class="btn btn-secondary">Volver</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/products/show.blade.php ENDPATH**/ ?>