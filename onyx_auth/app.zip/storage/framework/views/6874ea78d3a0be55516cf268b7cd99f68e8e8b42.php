<div class="table-responsive"> 
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col"><span class="guide-field">*</span>Razón social</th>
        <th scope="col"><span class="guide-field">*</span>Teléfono</th>
        <th scope="col"><span class="guide-field">*</span>Email</th>
        <th scope="col">Dirección</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($item->business_name); ?></td>
          <td><?php echo e($item->phone); ?></td>
          <td><?php echo e($item->email); ?></td>
          <td><?php echo e($item->address); ?></td>
          <td>
            <form action="<?php echo e(route('clients.destroy',$item->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro que deseas eliminar a este contacto?');">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
              <a href="<?php echo e(route('clients.show', $item->id)); ?>" class="btn btn-primary btn-sm" title="Edit item"><i class="fas fa-eye" ></i></a>
              <a href="<?php echo e(route('clients.edit', $item)); ?>" class="btn btn-success btn-sm" title="Edit item"><i class="fas fa-edit"></i></a>
              <button type="submit" class="btn btn-danger btn-sm" title="Delete item"><i class="fa fa-minus-circle" ></i></button>
            </form> 
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div> 
<?php echo e($clients->links()); ?>  <?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/clients/partials/results.blade.php ENDPATH**/ ?>