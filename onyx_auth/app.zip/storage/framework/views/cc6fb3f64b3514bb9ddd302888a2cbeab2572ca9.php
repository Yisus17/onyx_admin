<table class="table table-bordered table-sm">
  <tbody>

    <tr class="table-soft-header">
      <th colspan="3">Código</th>
      <th colspan="9">Descripción</th>
    </tr>
    <tr>
      <td colspan="3"><?php echo e($product->code); ?></th>
      <td colspan="9"><?php echo e($product->pivot->description); ?></th>
    </tr>

    <tr class="table-soft-header">
      <th colspan="3">Cantidad</th>
      <th colspan="3">Factor</th>
      <th colspan="3">Precio unitario</th>
      <th colspan="3">Descuento</th>
    </tr>
    <tr>
      <td colspan="3"><?php echo e($product->pivot->quantity); ?></td>
      <td colspan="3"><?php echo e($product->pivot->factor); ?></td>
      <td colspan="3"><?php echo e(getFormattedPrice($product->pivot->unit_price)); ?>€</td>
      <td colspan="3"><?php echo e($product->pivot->discount); ?>%</td>
    </tr>

    <tr class="table-soft-header text-right">
      <th colspan="12">Base imponible</th>
    </tr>
    <tr class="text-right">
      <td colspan="12"><?php echo e(getFormattedPrice($product->pivot->total_price)); ?>€</th>
    </tr>
    
  </tbody>
</table><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/partials/show/budget_products_table.blade.php ENDPATH**/ ?>