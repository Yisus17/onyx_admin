<table class="table table-bordered table-sm">
  <tbody>
    <tr class="table-soft-header">
      <th colspan="4">Fecha de elaboración</th>
      <th colspan="4">Contacto</th>
      <th colspan="4">Validez</th>
    </tr>
    <tr>
      <td colspan="4"><?php echo e($budget->created_at ? $budget->created_at->format('d/m/Y H:m') : ''); ?></td>
      <td colspan="4"><?php echo e($budget->client->name); ?></td>
      <td colspan="4"><?php echo e($budget->validity ? findValue(getValidityOptions(), $budget->validity): ''); ?></td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="6">Dirección</th>
      <th colspan="6">Descripción del evento</th>
    </tr>
    <tr>
      <td colspan="6"><?php echo e($budget->address); ?></td>
      <td colspan="6"><?php echo e($budget->description); ?></td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="4">Entrega</th>
      <th colspan="4">Devolución</th>
      <th colspan="4">Montaje</th>
    </tr>
    <tr>
      <td colspan="4"><?php echo e($budget->delivery_date ? $budget->delivery_date->format('d/m/Y H:m') : ''); ?></td>
      <td colspan="4"><?php echo e($budget->return_date ? $budget->return_date->format('d/m/Y H:m') : ''); ?></td>
      <td colspan="4"><?php echo e($budget->instalation_date ? $budget->instalation_date->format('d/m/Y H:m') : ''); ?></td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="4">Inicio evento</th>
      <th colspan="4">Fin evento</th>
      <th colspan="4">Desmontaje</th>
    </tr>
    <tr>
      <td colspan="4"><?php echo e($budget->start_date ? $budget->start_date->format('d/m/Y H:m') : ''); ?></td>
      <td colspan="4"><?php echo e($budget->end_date ? $budget->end_date->format('d/m/Y H:m') : ''); ?></td>
      <td colspan="4"><?php echo e($budget->uninstalation_date ? $budget->uninstalation_date->format('d/m/Y H:m') : ''); ?></td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="6">Condiciones de pago</th>
      <th colspan="6">Método de pago</th>
    </tr>
    <tr>
      <td colspan="6"><?php echo e($budget->payment_conditions ? findValue(getPaymentConditions(), $budget->payment_conditions) : ''); ?></td>
      <td colspan="6"><?php echo e($budget->payment_method ? findValue(getPaymentMethods(), $budget->payment_method) : ''); ?></td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="4">Total (Base imponible)</th>
      <th colspan="4">IVA</th>
      <th colspan="4">Total (IVA incluido)</th>
    </tr>
    <tr>
      <td colspan="4"><?php echo e(getFormattedPrice($budget->total)); ?>€</td>
      <td colspan="4"><?php echo e(getFormattedPrice($budget->tax_amount)); ?>€</td>
      <td colspan="4"><?php echo e(getFormattedPrice($budget->total_with_tax)); ?>€</td>
    </tr>

    <tr class="table-soft-header">
      <th colspan="12">Notas</th>
    </tr>
    <tr>
      <td colspan="12"><?php echo e($budget->notes); ?></td>
    </tr>
  </tbody>
</table><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/partials/show/budget_data_table.blade.php ENDPATH**/ ?>