<div class="table-responsive">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col"><span class="guide-field">*</span>Código</th>
        <th scope="col"><span class="guide-field">*</span>Modelo</th>
        <th scope="col"><span class="guide-field">*</span>Descripción</th>
        <th scope="col"><span class="guide-field">*</span>Rubro</th>
        <th scope="col">Precio de compra</th>
        <th scope="col">Fecha de compra</th>
        <th scope="col">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($item->code); ?></th>
        <td><?php echo e($item->model); ?></td>
        <!--Limita caracteres de la celda-->
        <td><?php echo e(\Illuminate\Support\Str::limit($item->description,15 , '...')); ?></td>
        <td><?php echo e($item->category->name); ?></td>
        <td><?php echo e($item->purchase_price ? $item->purchase_price.'€' : ''); ?></td>
        <td><?php echo e($item->purchase_date ? $item->purchase_date->format('d/m/Y') : ''); ?></td>
        <td id="actions_td">
          <form action="<?php echo e(route('products.destroy',$item->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro que deseas eliminar a este producto?');">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <a href="<?php echo e(route('products.show', $item->id)); ?>" class="btn btn-primary btn-sm" title="Edit item"><i class="fas fa-eye"></i></a>
            <a href="<?php echo e(route('products.edit', $item)); ?>" class="btn btn-success btn-sm" title="Edit item"><i class="fas fa-edit"></i></a>
            <button type="submit" class="btn btn-danger btn-sm" title="Delete item"><i class="fa fa-minus-circle"></i></button>
          </form>

        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php echo e($products->links()); ?>

<?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/products/partials/results.blade.php ENDPATH**/ ?>