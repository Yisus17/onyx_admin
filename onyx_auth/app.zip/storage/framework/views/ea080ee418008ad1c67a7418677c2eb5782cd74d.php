<div class="form-group required-info">
  <span>*Campos obligatorios</span>
</div>

<!-- Invoice data -->
<?php echo $__env->make('invoices.partials.form.invoice_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End invoice data -->
  
<!-- Invoice products -->
  <?php echo $__env->make('invoices.partials.form.invoice_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<!-- End invoice products -->

<!-- Form actions -->
<div class="row">
  <div class="form-group col-12">
    <button class="btn btn-primary " type="submit">Guardar</button>
    <a href="/invoices" class="btn btn-secondary">Volver</a>
  </div>
</div>
<!-- End form actions -->







<?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/invoices/partials/form.blade.php ENDPATH**/ ?>