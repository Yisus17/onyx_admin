<table>
  <tbody>
    <!-- HEADER -->
    <tr>
      <td colspan="9" style="text-align:center; height: 60px">
      </td>
    </tr>
    <tr>
      <th colspan="9" style="text-align:center; font-size: 16px"><?php echo e(getOnyxBusinessName()); ?></th>
    </tr>
    <tr>
      <td colspan="9" style="text-align:center;font-size: 8px"><?php echo e(getOnyxAddress()); ?></td>
    </tr>
    <tr>
      <td colspan="9" style="text-align:center;font-size: 8px"><?php echo e(getOnyxInfo()); ?></td>
    </tr>

    <tr>
      <td colspan="3" style="text-align:left; vertical-align: top"><b>Presupuesto #<?php echo e($budget->id); ?></b></td>
      <td colspan="3">&nbsp;</td>
      <td colspan="3" style="text-align:right;">Fecha de elaboración: <?php echo e($budget->created_at ? $budget->created_at->format('d/m/Y') : ''); ?></td>
    </tr>

    <!-- CLIENT DATA -->
    <tr>
      <td colspan="1">Contacto</td>
      <td colspan="8"><?php echo e($budget->client->business_name); ?></td>
    </tr>

    <tr>
      <td colspan="1">Direccion</td>
      <td colspan="8"><?php echo e($budget->client->address); ?></td>
    </tr>

    <tr>
      <td colspan="1">Teléfono</td>
      <td colspan="8" style="text-align:left;"><?php echo e($budget->client->phone); ?></td>
    </tr>

    <tr>
      <td colspan="1">Email</td>
      <td colspan="8"><?php echo e($budget->client->email); ?></td>
    </tr>

    <!-- SEPARATOR -->
    <tr>
      <td colspan="9"></td>
    </tr>

    <!-- BUDGET DATES AND LOCATION -->

    <tr>
      <td colspan="1" style="border: 1px solid black;">Entrega</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->delivery_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->delivery_date->format('H:m')); ?></td>
      <td colspan="3">&nbsp;</td>
      <td colspan="1" style="border: 1px solid black;">Fin evento</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->end_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->end_date->format('H:m')); ?></td>
    </tr>

    <tr>
      <td colspan="1" style="border: 1px solid black;">Montaje</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->instalation_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->instalation_date->format('H:m')); ?></td>
      <td colspan="3">&nbsp;</td>
      <td colspan="1" style="border: 1px solid black;">Desmontaje</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->uninstalation_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->uninstalation_date->format('H:m')); ?></td>
    </tr>

    <tr>
      <td colspan="1" style="border: 1px solid black;">Inicio evento</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->start_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->start_date->format('H:m')); ?></td>
      <td colspan="3">&nbsp;</td>
      <td colspan="1" style="border: 1px solid black;">Devolución</td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->return_date->format('d/m/Y')); ?></td>
      <td colspan="1" style="border: 1px solid black;"><?php echo e($budget->return_date->format('H:m')); ?></td>
    </tr>

    <tr>
      <td colspan="9" style="border: 1px solid black;">Locación: <?php echo e($budget->address); ?></td>
    </tr>

    <!-- SEPARATOR -->
    <tr>
      <td colspan="9"></td>
    </tr>

    <!-- PRODUCTS -->

    <?php if($budget->products): ?>
      <?php $__currentLoopData = $budget->products->groupBy('category_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key == 0): ?>
            <tr>
              <td colspan="9" style="font-weight: bold;"><?php echo e($product->category->name); ?></td>
            </tr>
            <tr>
              <td colspan="1">Cantidad</td>
              <td colspan="4">Descripción</td>
              <td colspan="1">Factor</td>
              <td colspan="1">Descuento</td>
              <td colspan="1">P/Unitario</td>
              <td colspan="1">P/Total</td>
            </tr>
          <?php endif; ?>
          <tr>
            <td colspan="1" style="text-align:right;"><?php echo e($product->pivot->quantity); ?></td>
            <td colspan="4"><?php echo e($product->pivot->description); ?></td>
            <td colspan="1" style="text-align:right;"><?php echo e($product->pivot->factor); ?></td>
            <td colspan="1" style="text-align:right;"><?php echo e($product->pivot->discount); ?>%</td>
            <td colspan="1" style="text-align:right;"><?php echo e(getFormattedPrice($product->pivot->unit_price)); ?>€</td>
            <td colspan="1" style="text-align:right;"><?php echo e(getFormattedPrice($product->pivot->total_price)); ?>€</td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- SEPARATOR -->
    <tr>
      <td colspan="9"></td>
    </tr>
    <tr>
      <td colspan="9"></td>
    </tr>

    <!-- TOTAL PRICES -->

    <tr>
      <td colspan="1">&nbsp;</td>
      <td colspan="7" style="font-weight: bold;text-align:left;">TOTAL (BASE IMPONIBLE)</td>
      <td colspan="1" style="font-weight: bold;text-align:right;"><?php echo e(getFormattedPrice($budget->total)); ?>€</td>
    </tr>

    <tr>
      <td colspan="1">&nbsp;</td>
      <td colspan="7" style="font-weight: bold;text-align:left;">IVA (<?php echo e($budget->tax_percentage); ?>%)</td>
      <td colspan="1" style="font-weight: bold;text-align:right;"><?php echo e(getFormattedPrice($budget->tax_amount)); ?>€</td>
    </tr>

    <tr>
      <td colspan="1">&nbsp;</td>
      <td colspan="7" style="font-weight: bold;text-align:left;">TOTAL (IVA INCLUIDO)</td>
      <td colspan="1" style="font-weight: bold;text-align:right;"><?php echo e(getFormattedPrice($budget->total_with_tax)); ?>€</td>
    </tr>

    <?php if($budget->notes): ?>
      <!-- SEPARATOR -->
      <tr>
        <td colspan="9"></td>
      </tr>
      <!-- NOTES -->
      <tr>
        <td colspan="9"><?php echo e($budget->notes); ?></td>
      </tr>
    <?php endif; ?>
  </tbody>
</table><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/excel.blade.php ENDPATH**/ ?>