<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>