<div class="loader-center hidden">
  <div class="spinner-border text-primary" role="status">
    <span class="sr-only"></span>
  </div>
</div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/partials/loader.blade.php ENDPATH**/ ?>