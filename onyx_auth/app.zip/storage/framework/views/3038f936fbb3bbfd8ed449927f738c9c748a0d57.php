

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-10">
      <!-- Breadcrumbs -->
      <?php echo e(Breadcrumbs::render('budgets.show', $budget)); ?>


      <!-- Session messages -->
      <?php echo $__env->make('partials.session_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
			<div class="card">
				<div class="card-header d-flex justify-content-between align-items-center">
          <span>Detalles del presupuesto <b>#<?php echo e($budget->id); ?></b></span>
          <a href="<?php echo e(route('budgets.excelExport', $budget->id)); ?>" class="btn btn-success btn-sm float-right">
            <span><i class="fas fa-file-excel mr-1"></i> Descargar excel</span>
          </a>
				</div>
				<div class="card-body">
        
          <!-- Budget data -->
          <?php echo $__env->make('budgets.partials.show.budget_data_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <hr>

          <!-- Budget products -->
          <h5>Productos</h5>
          <?php $__currentLoopData = $budget->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('budgets.partials.show.budget_products_table', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <a href="<?php echo e(route('budgets.edit', $budget)); ?>" class="btn btn-primary">Editar</a>
          <a href="/budgets" class="btn btn-secondary">Volver</a>
          <a 
            href="<?php echo e(route('budgets.duplicate', $budget->id)); ?>" 
            class="btn btn-primary float-right" 
            onclick="return confirm('¿Estás seguro que deseas duplicar a este presupuesto?');">
            <span><i class="fas fa-copy mr-1"></i> Duplicar</span>
          </a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/show.blade.php ENDPATH**/ ?>