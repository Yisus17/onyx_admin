

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-8">

		<!-- Breadcrumbs -->
		<?php echo e(Breadcrumbs::render('clients.edit', $client)); ?>


		<!-- Session messages -->
		<?php echo $__env->make('partials.session_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


			<div class="card">
				<div class="card-header d-flex justify-content-between align-items-center">
					<span>Editar contacto por: <?php echo e(auth()->user()->name); ?></span>
				</div>

				<div class="card-body">
					<?php echo Form::model($client, ['route' => ['clients.update', $client->id], 'method' => 'PUT']); ?>

							<?php echo $__env->make('clients.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php echo Form::close(); ?>

				</div>
				</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/clients/edit.blade.php ENDPATH**/ ?>