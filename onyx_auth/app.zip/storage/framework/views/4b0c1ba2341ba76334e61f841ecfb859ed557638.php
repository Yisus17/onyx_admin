<!-- Product selection -->
<div class="row mb-3">
    <div class="col-12">
      <hr>
    </div>
    <div class="form-group col-12">
      <label for="product_id">Productos</label>
      <div class="input-group select-add">
        <select id="product-select" class="form-control selectpicker" data-live-search="true">
          <option value="" selected disabled>--Selecciona una opción--</option>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($product->id); ?>"><?php echo e('('.$product->code.') '.$product->description); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="input-group-addon input-group-button">
          <button type="button" id="add-invoice-product" class="btn btn-primary disabled">Agregar</button>
        </div>
      </div>
      <small class="form-text text-muted">Busca productos para agregar a la factura</small>
    </div>
  </div>
<!-- End product selection -->

<!-- Invoice items -->
  <div class="row products-container justify-content-center">
    <?php if(isset($invoice) && isset($invoice->products)): ?>
      <?php $__currentLoopData = $invoice->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('invoices.product', ['product' => $invoice_product, 'uniqid' => Str::random(9)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
<!-- End invoice items -->

<?php $__env->startSection('scripts'); ?>
  ##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
  <script type="text/javascript">
    function checkAddBtn(){
      if($("#product-select").val()){
        $("#add-invoice-product").removeClass('disabled');
      }else{
        $("#add-invoice-product").addClass('disabled');
      }
    }

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });

    $('#product-select').change(function(e){
      checkAddBtn();
    });

    $('#add-invoice-product').click(function(e){
      e.preventDefault();
      var productId = $('#product-select').val();
      if(productId){
        $.ajax({
          type:'POST',
          url:'/invoices/addProduct',
          data:{product_id: productId},
          success:function(response){
            $('.products-container').append(response);
          },
          error:function(jqXHR, textStatus, errorThrown){
            alert('Ha ocurrido un error');
          },
        });
      }
    });

    $('.products-container').on('click', '.delete-product', function(event){
      event.preventDefault();
      $(this).closest('.product-container').remove();
    });
  </script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/invoices/partials/form/invoice_products.blade.php ENDPATH**/ ?>