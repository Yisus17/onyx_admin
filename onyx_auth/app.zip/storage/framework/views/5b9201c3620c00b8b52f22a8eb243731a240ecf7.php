

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row justify-content-center">
		<div class="col-md-12">
			<!-- Breadcrumbs -->
			<?php echo e(Breadcrumbs::render('invoices')); ?>


			<!-- Session messages -->
			<?php echo $__env->make('partials.session_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<!-- Search Bar -->
			<div class="row">
				<div class="input-group col-10">
					<input 
						type="text" 
						class="form-control search-bar" 
						id="search-invoice" 
						placeholder="Busca una factura" 
						value="<?php echo e(isset($querySearch) ? $querySearch : ''); ?>">
					<div class="input-group-append">
						<button class="btn btn-primary" id="submit-search-invoice" type="button">
							<i class="fas fa-search"></i>
						</button>
					</div>
				</div>
				<div class="col-2 clear-search">
					<button class="btn btn-outline-secondary" id="clear-search-invoice" type="button">
						Limpiar
					</button>
				</div>
			</div>

			<div class="form-group guide-info col-10">
				<span>*Campos de búsqueda</span>
			</div>

			<div class="card">
				<div class="card-header d-flex justify-content-between align-items-center">
					<span>Listado de facturas</span>
					<a href="/invoices/create" class="btn btn-primary btn-sm">Nueva factura</a>
				</div>

				<div class="card-body">   
					<?php echo $__env->make('partials.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
					<div id="invoice-list-container">
						<?php echo $__env->make('invoices.partials.results', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>   
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	function sendSearchInvoice() {
		let keyword = $('#search-invoice').val();
		$("#invoice-list-container").html("");
		$(".loader-center").removeClass("hidden");

		$.ajax({
			type: "GET",
			url: "<?php echo e(route('invoices.search')); ?>",
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			data: {
				keyword: keyword
			}
		}).done(function(data) {
			$(".loader-center").addClass("hidden");
			$("#invoice-list-container").html(data);
		});
	}


	$("#search-invoice").keypress(function(e) {
		let key = e.which;
		if (key == 13) { // the enter key code
			sendSearchInvoice();
		}
	});

	$("#submit-search-invoice").click(function() {
		sendSearchInvoice();
	});

	$("#clear-search-invoice").click(function() {
		$('#search-invoice').val('');
		sendSearchInvoice();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/invoices/list.blade.php ENDPATH**/ ?>