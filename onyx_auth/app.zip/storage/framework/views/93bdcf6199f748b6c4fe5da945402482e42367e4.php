<div class="custom-form row">
  <div class="form-group required-info col-12">
    <span>*Campos obligatorios</span>
  </div>
  
  <div class="form-group col-12">
    <label for="name"><span class="required-field">*</span>Razón Social</label>
    <input 
      type="text" 
      name="business_name" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->business_name : old('business_name')); ?>" 
      required/>
  </div>

  <div class="form-group col-12">
    <label for="address"><span class="required-field">*</span>Dirección</label>
    <textarea 
      class="form-control" 
      name="address" 
      rows="2" 
      required><?php echo e(isset($client) ? $client->address : old('address')); ?></textarea>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="postal_code">Código postal</label>
    <input 
      type="text" 
      name="postal_code" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->postal_code : old('postal_code')); ?>"/>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="community_id">Comunidad autónoma</label>
    <select name="community_id" class="form-control selectpicker" data-live-search="true">
      <option value="" selected disabled>--Selecciona una opción--</option>
      <?php $__currentLoopData = $communities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $community): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($community->id); ?>" <?php echo e((isset($client) && $community->id == $client->community_id) || old('community_id') == $community->id ? 'selected' : ''); ?>><?php echo e($community->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="phone"><span class="required-field">*</span>Teléfono</label>
    <input 
      type="text" 
      name="phone" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->phone : old('phone')); ?>" 
      required/>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="secondary_phone">Teléfono secundario</label>
    <input 
      type="text" 
      name="secondary_phone" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->secondary_phone : old('secondary_phone')); ?>" />
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="name"><span class="required-field">*</span>Nombre</label>
    <input 
      type="text" 
      name="name" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->name : old('name')); ?>" 
      required/>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="lastname"><span class="required-field">*</span>Apellido</label>
    <input 
      type="text" 
      name="lastname" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->lastname : old('lastname')); ?>" 
      required/>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="email"><span class="required-field">*</span>Email</label>
    <input 
      type="email" 
      name="email" 
      class="form-control" 
      value="<?php echo e(isset($client) ? $client->email : old('email')); ?>" 
      required/>
  </div>

  <div class="form-group col-12 col-sm-6">
    <label for="client_type_id">Tipo</label>
    <select name="client_type_id" class="form-control selectpicker" data-live-search="true">
      <option value="" selected disabled>--Selecciona una opción--</option>
      <?php $__currentLoopData = $clientTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($clientType->id); ?>" <?php echo e((isset($client) && $clientType->id == $client->client_type_id) || old('client_type_id') == $clientType->id ? 'selected' : ''); ?>><?php echo e($clientType->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>

  <div class="form-group col-12">
    <button class="btn btn-primary " type="submit">Guardar</button>
    <a href="/clients" class="btn btn-secondary">Volver</a>
  </div>
</div><?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/clients/partials/form.blade.php ENDPATH**/ ?>