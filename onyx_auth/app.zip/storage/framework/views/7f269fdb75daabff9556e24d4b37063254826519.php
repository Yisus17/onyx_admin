<div class="form-group required-info">
  <span>*Campos obligatorios</span>
</div>

<!-- Budget data -->
  <?php echo $__env->make('budgets.partials.form.budget_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End budget data -->
  
<!-- Budget products -->
  <?php echo $__env->make('budgets.partials.form.budget_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<!-- End budget products -->

<!-- Form actions -->
<div class="row">
  <div class="form-group col-12">
    <button class="btn btn-primary " type="submit">Guardar</button>
    <a href="/budgets" class="btn btn-secondary">Volver</a>
  </div>
</div>
<!-- End form actions -->







<?php /**PATH C:\xampp\htdocs\proyectos\laravel\onyx\onyx_auth\resources\views/budgets/partials/form.blade.php ENDPATH**/ ?>